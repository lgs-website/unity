var classOnlineMapsGooglePlacesResult =
[
    [ "Photo", "classOnlineMapsGooglePlacesResult_1_1Photo.html", "classOnlineMapsGooglePlacesResult_1_1Photo" ],
    [ "OnlineMapsGooglePlacesResult", "classOnlineMapsGooglePlacesResult.html#a8f6443a171f9aa480623c6efaf7b08fd", null ],
    [ "formatted_address", "classOnlineMapsGooglePlacesResult.html#abe561af604faad8a503be0d8e9ecf804", null ],
    [ "icon", "classOnlineMapsGooglePlacesResult.html#a7db37b625a07b0cef04e5509cbb8d8d9", null ],
    [ "id", "classOnlineMapsGooglePlacesResult.html#ac946624eca5b2a4d09e9c3a8598351c9", null ],
    [ "location", "classOnlineMapsGooglePlacesResult.html#af672130da45642b3111e46be17eab614", null ],
    [ "name", "classOnlineMapsGooglePlacesResult.html#a3cc7e4b1d39352980683b77a515c6ab2", null ],
    [ "open_now", "classOnlineMapsGooglePlacesResult.html#a36078e3dfea7b76e9540c7fde69d9b79", null ],
    [ "photos", "classOnlineMapsGooglePlacesResult.html#af9c780343366a692dce41c26831d07c0", null ],
    [ "place_id", "classOnlineMapsGooglePlacesResult.html#a15e8e217331cd222e85d5d52a3fbdf2d", null ],
    [ "price_level", "classOnlineMapsGooglePlacesResult.html#a5f52ea0e136d1449d868f980f82a244f", null ],
    [ "rating", "classOnlineMapsGooglePlacesResult.html#af6b5d8847e9479a08eafd43680c89ea9", null ],
    [ "reference", "classOnlineMapsGooglePlacesResult.html#a2753b3e208b9e9b76155de42e9294455", null ],
    [ "scope", "classOnlineMapsGooglePlacesResult.html#ac58c06bb3da70d04452aaceec2b19f08", null ],
    [ "types", "classOnlineMapsGooglePlacesResult.html#a52f3d91530ff0c7851d510e16754d1a3", null ],
    [ "vicinity", "classOnlineMapsGooglePlacesResult.html#aa2440f15758dd86d35a82efae46ce405", null ],
    [ "weekday_text", "classOnlineMapsGooglePlacesResult.html#a8df21f33522a83a46cb20bdf7dc9c654", null ]
];