var classOnlineMapsOpenRouteServiceGeocodingResult_1_1Properties =
[
    [ "city", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Properties.html#af591c4ca4fe6ef52a552760f0b8f5dda", null ],
    [ "confidence", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Properties.html#a81029d844ac92561c59318823730b679", null ],
    [ "country", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Properties.html#a43bdeed50769d76f88001b4b54b3b76b", null ],
    [ "county", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Properties.html#aafd9595f966ec1c9fd6eefa538eb0082", null ],
    [ "distance", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Properties.html#af76a232036bc91e48e1894e6c250c512", null ],
    [ "house_number", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Properties.html#a431475135a16ae54906f6eeba67768e8", null ],
    [ "name", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Properties.html#a817ca06305e75f9ed3a7eb6da8d6b3c0", null ],
    [ "postal_code", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Properties.html#afe9c90509a8f1e12fe62c2e643e55ef9", null ],
    [ "state", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Properties.html#a13d4f9f567dc3cfb49f6a65879467bd6", null ],
    [ "street", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Properties.html#a30763869e04a76c6d7f62dcd0aa6d8a6", null ]
];