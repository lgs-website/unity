var classOnlineMapsQQSearchResult_1_1Data =
[
    [ "ad_info", "classOnlineMapsQQSearchResult_1_1Data.html#aca399aae97660f6b2a077328534beec9", null ],
    [ "address", "classOnlineMapsQQSearchResult_1_1Data.html#af4aaada3c5c18381587fe4128fc4ea53", null ],
    [ "boundary", "classOnlineMapsQQSearchResult_1_1Data.html#a80e44482376a8e3d5611ccc73cb4b05c", null ],
    [ "category", "classOnlineMapsQQSearchResult_1_1Data.html#a8ebfb12f9f2e753916a16c9b63e98955", null ],
    [ "id", "classOnlineMapsQQSearchResult_1_1Data.html#a18d463efe5867521614c19d3da78a67b", null ],
    [ "location", "classOnlineMapsQQSearchResult_1_1Data.html#ad0e036508dc2d9bb06aba5e79fb3ee1b", null ],
    [ "pano", "classOnlineMapsQQSearchResult_1_1Data.html#a50c2dce2a578a895bffeda97e3140f6c", null ],
    [ "tel", "classOnlineMapsQQSearchResult_1_1Data.html#abda22b378f9adf2a6f6130a19b47dbda", null ],
    [ "title", "classOnlineMapsQQSearchResult_1_1Data.html#a01d1768152bb717e9fb7f29edf26939e", null ],
    [ "type", "classOnlineMapsQQSearchResult_1_1Data.html#abf807a2b60df4572616d17a8af996e32", null ]
];