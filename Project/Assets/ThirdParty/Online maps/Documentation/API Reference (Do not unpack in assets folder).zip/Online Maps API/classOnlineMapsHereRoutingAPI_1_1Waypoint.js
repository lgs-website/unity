var classOnlineMapsHereRoutingAPI_1_1Waypoint =
[
    [ "type", "classOnlineMapsHereRoutingAPI_1_1Waypoint.html#a58ee6998e6bf322e1a3a987e56b98eff", null ]
];