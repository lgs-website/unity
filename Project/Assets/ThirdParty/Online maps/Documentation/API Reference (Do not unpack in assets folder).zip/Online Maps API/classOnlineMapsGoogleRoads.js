var classOnlineMapsGoogleRoads =
[
    [ "Location", "classOnlineMapsGoogleRoads_1_1Location.html", "classOnlineMapsGoogleRoads_1_1Location" ],
    [ "SnapToRoadResult", "classOnlineMapsGoogleRoads_1_1SnapToRoadResult.html", "classOnlineMapsGoogleRoads_1_1SnapToRoadResult" ],
    [ "SpeedLimitResult", "classOnlineMapsGoogleRoads_1_1SpeedLimitResult.html", "classOnlineMapsGoogleRoads_1_1SpeedLimitResult" ],
    [ "Units", "classOnlineMapsGoogleRoads.html#a4d3621d31a09e3b27863ee373f2cbec7", [
      [ "KPH", "classOnlineMapsGoogleRoads.html#a4d3621d31a09e3b27863ee373f2cbec7ab46325e65c9082522eada8e32e5180d6", null ],
      [ "MPH", "classOnlineMapsGoogleRoads.html#a4d3621d31a09e3b27863ee373f2cbec7a886e8f3873e1b57c2049968ed8444ab7", null ]
    ] ],
    [ "GetSnapToRoadResults", "classOnlineMapsGoogleRoads.html#a5c7dc52a040d3f20ba09b3e88501e642", null ],
    [ "GetSpeedLimitResults", "classOnlineMapsGoogleRoads.html#abe4f30ff2e711bb0cf9bb8f56b0ac19d", null ],
    [ "SnapToRoads", "classOnlineMapsGoogleRoads.html#a172b1fc8bd6cf2817e47a4c031850cd1", null ],
    [ "SpeedLimits", "classOnlineMapsGoogleRoads.html#a044f352787a97415f8e5d4894c361ab5", null ]
];