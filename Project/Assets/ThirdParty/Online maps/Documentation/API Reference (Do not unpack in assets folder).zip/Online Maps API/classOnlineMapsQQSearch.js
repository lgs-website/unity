var classOnlineMapsQQSearch =
[
    [ "Params", "classOnlineMapsQQSearch_1_1Params.html", "classOnlineMapsQQSearch_1_1Params" ],
    [ "Find", "classOnlineMapsQQSearch.html#a5363e1a4903c29537b3c9cab3eabc45e", null ],
    [ "GetResult", "classOnlineMapsQQSearch.html#a6bda48b393f9695cab466349bf3005c3", null ]
];