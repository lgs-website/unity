var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg =
[
    [ "baseTime", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#aa2a59257a1ed82a91a7570997cfa4576", null ],
    [ "boundingBox", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#a1c7001cc6ebd6498a098cdbab9c9c2b3", null ],
    [ "end", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#a49d2ad19ceaf780d18769270147ce89a", null ],
    [ "firstPoint", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#aae14d896602da05f480095c7cc8aae17", null ],
    [ "lastPoint", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#aa7988a8b1bae7948d4782bcae0d12fe1", null ],
    [ "length", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#ada679d979e44f8a2e5f0de527bd525c2", null ],
    [ "links", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#a6358abc7001e009cd36f310892757e80", null ],
    [ "maneuvers", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#a4350a9c5f6be3c5351820bfd9b64aefb", null ],
    [ "shape", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#a81d3ee11aa7dbb88be64421cc4d5f986", null ],
    [ "start", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#a50f1fb76a1c90c6a6d3be124ff096b58", null ],
    [ "subLegSummary", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#a02a0dfc9b9dfcb8d82e1421e3e1dfd7d", null ],
    [ "summary", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#ad2e935b299185559c92ff62ab99696be", null ],
    [ "trafficTime", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#a26226c110e2b3b9304a3514cd7bd9f4c", null ],
    [ "travelTime", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Leg.html#a8b1e386ec1edc84e5af16ebf6a7cad89", null ]
];