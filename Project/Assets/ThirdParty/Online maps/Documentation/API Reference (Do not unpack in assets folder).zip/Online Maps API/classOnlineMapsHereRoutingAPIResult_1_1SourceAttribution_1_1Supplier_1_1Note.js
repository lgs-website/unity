var classOnlineMapsHereRoutingAPIResult_1_1SourceAttribution_1_1Supplier_1_1Note =
[
    [ "href", "classOnlineMapsHereRoutingAPIResult_1_1SourceAttribution_1_1Supplier_1_1Note.html#a5f1883cd4d14d6c50cea1ace35932c14", null ],
    [ "hrefText", "classOnlineMapsHereRoutingAPIResult_1_1SourceAttribution_1_1Supplier_1_1Note.html#a2e2e79b22d525264b950bf954b0f628c", null ],
    [ "text", "classOnlineMapsHereRoutingAPIResult_1_1SourceAttribution_1_1Supplier_1_1Note.html#abaab8c7a49c6441ed1b2c26a52d8e4c4", null ],
    [ "type", "classOnlineMapsHereRoutingAPIResult_1_1SourceAttribution_1_1Supplier_1_1Note.html#a33c28a8298176a4366a1226acb4add9a", null ]
];