var classOnlineMapsProjection =
[
    [ "CoordinatesToTile", "classOnlineMapsProjection.html#aa4c0dcbd4fd0be9199e712d1845170e0", null ],
    [ "TileToCoordinates", "classOnlineMapsProjection.html#ad95c8e7062eb17b18c7f9ea8e3cbabe9", null ],
    [ "DEG2RAD", "classOnlineMapsProjection.html#aba34f864d4f783669f2583425e51c4df", null ],
    [ "PI2", "classOnlineMapsProjection.html#ab0e8a3d5ca089b6d3af722641bb7037d", null ],
    [ "PI4", "classOnlineMapsProjection.html#a4b23b08dd869f5ad7e350f623c2f6d0d", null ],
    [ "RAD2DEG", "classOnlineMapsProjection.html#a7d24f578f5a0e506f0f33c37349b4b38", null ]
];