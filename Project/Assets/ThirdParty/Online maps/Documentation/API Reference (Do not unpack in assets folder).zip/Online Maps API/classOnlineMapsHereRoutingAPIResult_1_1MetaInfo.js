var classOnlineMapsHereRoutingAPIResult_1_1MetaInfo =
[
    [ "interfaceVersion", "classOnlineMapsHereRoutingAPIResult_1_1MetaInfo.html#a3879f180096fa9692e72659a3395e585", null ],
    [ "mapVersion", "classOnlineMapsHereRoutingAPIResult_1_1MetaInfo.html#a848afe869631c9845b7552a9c9f59550", null ],
    [ "moduleVersion", "classOnlineMapsHereRoutingAPIResult_1_1MetaInfo.html#afcc97a2138e8876a971dc61d6a5a2a47", null ],
    [ "requestId", "classOnlineMapsHereRoutingAPIResult_1_1MetaInfo.html#a13c9234187d80f02d9d0381c68ddb7d3", null ],
    [ "timestamp", "classOnlineMapsHereRoutingAPIResult_1_1MetaInfo.html#aa33042650955d8c71a8fbf49d951a18a", null ]
];