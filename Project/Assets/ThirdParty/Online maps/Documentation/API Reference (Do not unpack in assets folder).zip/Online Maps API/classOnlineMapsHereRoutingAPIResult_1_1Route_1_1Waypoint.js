var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Waypoint =
[
    [ "label", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Waypoint.html#ac572906ad3a951028ce8ca515ef6bf89", null ],
    [ "linkId", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Waypoint.html#a3cd348eb4e00bfc73a2f76ad16c17534", null ],
    [ "mappedPosition", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Waypoint.html#adda41dc88f7630c47203ae130e0896e7", null ],
    [ "mappedRoadName", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Waypoint.html#ac110e972f857f86a46640b28b6fdcf8d", null ],
    [ "originalPosition", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Waypoint.html#aa121257564d12033d906f74f5bece181", null ],
    [ "shapeIndex", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Waypoint.html#a9839455fe939ec3eaed0f0fa7dc2b5af", null ],
    [ "sideOfStreet", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Waypoint.html#a42933454e3cc153e1c4dac9c1b9812ad", null ],
    [ "spot", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Waypoint.html#a89ced2c6457b356e676a46f8786ac30c", null ],
    [ "type", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Waypoint.html#a2e21231113791513f7f7ebdd177dcb53", null ],
    [ "userLabel", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Waypoint.html#ab373ac8669639247726cc82ae658e5f5", null ]
];