var classOnlineMapsOpenRouteServiceDirectionResult_1_1Step =
[
    [ "distance", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Step.html#a87e49880b08fed18d6ec9ed6ffdb67f0", null ],
    [ "duration", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Step.html#ad19d77a2d554ad8b68c3189e4de2f6b8", null ],
    [ "instruction", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Step.html#a1cf6363ae9845ca3408743aac4e80652", null ],
    [ "type", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Step.html#af342d8bdd13ba76b5903e401ea3d7844", null ],
    [ "way_points", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Step.html#a59b086d174fe0e50142e5fd5fda35634", null ]
];