var classOnlineMapsOpenRouteServiceDirectionResult_1_1Route =
[
    [ "extras", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Route.html#ab061e9b7c196f44d81b38a53f3741468", null ],
    [ "geometry", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Route.html#aba1e4bd92ef445f9248813f01a14882b", null ],
    [ "geometry_format", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Route.html#a7fdbec4a30e5bcd68b2704aeb981162e", null ],
    [ "segments", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Route.html#a96a5ab398c29ce31f7cc121495f49936", null ],
    [ "summary", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Route.html#a4db5c0df7ab4809ba497c0bad8a35363", null ],
    [ "way_points", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Route.html#a3aac59b497529e2a7782b236a9cad899", null ],
    [ "points", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Route.html#abf15f05c5629d6b729c185a1dd18184e", null ]
];