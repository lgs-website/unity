var classOnlineMapsGoogleRoads_1_1SpeedLimitResult =
[
    [ "placeId", "classOnlineMapsGoogleRoads_1_1SpeedLimitResult.html#a06d4acbfb795071801aa858d69c99395", null ],
    [ "speedLimit", "classOnlineMapsGoogleRoads_1_1SpeedLimitResult.html#a64b1eec081db59572f3e2a76210c63a4", null ],
    [ "units", "classOnlineMapsGoogleRoads_1_1SpeedLimitResult.html#a208916330116e215f6361e6047154058", null ]
];