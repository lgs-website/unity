var classOnlineMapsOpenRouteServiceDirectionResult_1_1ExtraItemSummary =
[
    [ "amount", "classOnlineMapsOpenRouteServiceDirectionResult_1_1ExtraItemSummary.html#a948917d6b34403f2b2dd6cee01756226", null ],
    [ "distance", "classOnlineMapsOpenRouteServiceDirectionResult_1_1ExtraItemSummary.html#afd90511ace5efa699cc9c35f2526080f", null ],
    [ "value", "classOnlineMapsOpenRouteServiceDirectionResult_1_1ExtraItemSummary.html#a88506d81896e12580af045e9fdf42e30", null ]
];