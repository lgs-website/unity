var classOnlineMapsWebServiceAPI =
[
    [ "Destroy", "classOnlineMapsWebServiceAPI.html#a7bcb65fe52879eafcc427adffd8dd085", null ],
    [ "customData", "classOnlineMapsWebServiceAPI.html#ac9c5d658dbc10be300b53328a4fc1826", null ],
    [ "OnDispose", "classOnlineMapsWebServiceAPI.html#a2d042cdaf682b26e246d434d98d64468", null ],
    [ "OnFinish", "classOnlineMapsWebServiceAPI.html#a5e73e9a5ed58d745bcbb47c3c958051b", null ],
    [ "status", "classOnlineMapsWebServiceAPI.html#aac38aae2d7ab77c7c01d35f76ea8cf7a", null ]
];