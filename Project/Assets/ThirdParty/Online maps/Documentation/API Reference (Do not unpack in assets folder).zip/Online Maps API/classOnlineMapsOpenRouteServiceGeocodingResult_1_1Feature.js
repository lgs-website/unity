var classOnlineMapsOpenRouteServiceGeocodingResult_1_1Feature =
[
    [ "geometry", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Feature.html#a60ea520f7eeda2a8dea0c8a13b6572d3", null ],
    [ "properties", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Feature.html#afdd53c0e5e806096541bd1a531b02a62", null ],
    [ "type", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Feature.html#aabbfb2cd29992a19d1c5d1b7ac07f0a5", null ]
];