var structOnlineMapsBuildingBase_1_1MetaInfo =
[
    [ "info", "structOnlineMapsBuildingBase_1_1MetaInfo.html#a7f533ebd6e740be83380531cb5b50ea8", null ],
    [ "title", "structOnlineMapsBuildingBase_1_1MetaInfo.html#a287537fdfb50686cac27b8c753869c89", null ]
];