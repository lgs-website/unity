var classOnlineMapsLocationService =
[
    [ "StartLocationService", "classOnlineMapsLocationService.html#ac376d58244faf7924de8b188394494d1", null ],
    [ "desiredAccuracy", "classOnlineMapsLocationService.html#a9327e3d699ee254d611cc51db0b8d78c", null ],
    [ "updateDistance", "classOnlineMapsLocationService.html#a44d517e9448724b89a7c79929faa896b", null ]
];