var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1ExternalResource =
[
    [ "filename", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1ExternalResource.html#a7c6f4320f6c8275b5ab1107b0ca63d25", null ],
    [ "resourceType", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1ExternalResource.html#acb3a4e6499dbdfecdedd0913a6171aa9", null ]
];