var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Note =
[
    [ "additionalData", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Note.html#a8528509400039e104a73ef02c321de73", null ],
    [ "code", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Note.html#ab1c5435ae987f3ae0e0b46738595ccb9", null ],
    [ "text", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Note.html#aa0929dfdc3d4f490df95da8e04457044", null ],
    [ "type", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Note.html#a6730507a6057cc72e218e214b20d0e77", null ]
];