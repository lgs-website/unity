var classOnlineMapsProjectionWGS84 =
[
    [ "CoordinatesToTile", "classOnlineMapsProjectionWGS84.html#a21fdb06909bcf646dd7d42bcb0afba81", null ],
    [ "TileToCoordinates", "classOnlineMapsProjectionWGS84.html#a31d60a2ccfb7f52b3c8cec82e78300f1", null ],
    [ "PID4", "classOnlineMapsProjectionWGS84.html#a62d5543ac3c13a34f4655df306a60af4", null ]
];