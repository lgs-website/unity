var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1ManueverGroup =
[
    [ "arrivalDescription", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1ManueverGroup.html#a2116060c9079684d77847399ff98dc7b", null ],
    [ "firstmaneuver", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1ManueverGroup.html#a29043e746a88a01175d425f3fed85e16", null ],
    [ "lastmaneuver", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1ManueverGroup.html#a81058a469bfd25dddc773e6dc6c3900c", null ],
    [ "mode", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1ManueverGroup.html#ad9b5240a822a0a49f6c43cff57058038", null ],
    [ "publicTransportType", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1ManueverGroup.html#a164ae82275799eacdfbd9919beff85ce", null ],
    [ "summaryDescription", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1ManueverGroup.html#a38e807d77fe7bd801280ca2eadd54b78", null ],
    [ "waitDescription", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1ManueverGroup.html#a759e9f83d0e1e317278454255947c261", null ]
];