var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Maneuver_1_1RoadShield =
[
    [ "category", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Maneuver_1_1RoadShield.html#a53c24c29685bf69d99de3f8bb78bdfd6", null ],
    [ "label", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Maneuver_1_1RoadShield.html#a41da92cc7aa8dffc2a529adc35f7d2c3", null ],
    [ "region", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Maneuver_1_1RoadShield.html#a77972293d1e89ca1213c52d3648da05f", null ]
];