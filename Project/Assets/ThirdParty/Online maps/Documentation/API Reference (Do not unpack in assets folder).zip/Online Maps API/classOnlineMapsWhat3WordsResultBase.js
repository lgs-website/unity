var classOnlineMapsWhat3WordsResultBase =
[
    [ "code", "classOnlineMapsWhat3WordsResultBase.html#ad5c6696702aaee18d8c095ae58706537", null ],
    [ "message", "classOnlineMapsWhat3WordsResultBase.html#a3e5d9075a289fb7ae09d65cc7dbc6634", null ]
];