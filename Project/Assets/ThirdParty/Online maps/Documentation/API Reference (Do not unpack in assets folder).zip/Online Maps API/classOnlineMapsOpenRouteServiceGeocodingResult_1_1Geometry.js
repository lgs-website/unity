var classOnlineMapsOpenRouteServiceGeocodingResult_1_1Geometry =
[
    [ "coordinates", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Geometry.html#a9a44c3ff357e4e224318813cd4aa1c16", null ],
    [ "type", "classOnlineMapsOpenRouteServiceGeocodingResult_1_1Geometry.html#a78e6e1f2dbf5742ee5779c1b99505e6d", null ]
];