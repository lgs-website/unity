var classOnlineMapsOpenRouteServiceDirectionResult_1_1Summary =
[
    [ "ascent", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Summary.html#ae3000f6ba9f4e68feaa4c6b937252076", null ],
    [ "descent", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Summary.html#ae964fd23c91ce259984f3499522f623e", null ],
    [ "distance", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Summary.html#acb6ac70a0ee5ee73d817b7242393c9d6", null ],
    [ "duration", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Summary.html#aaac43de5fd3ee26731ad78fc8882f79b", null ]
];