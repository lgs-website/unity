var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine =
[
    [ "ExternalResource", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1ExternalResource.html", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1ExternalResource" ],
    [ "Stop", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1Stop.html", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1Stop" ],
    [ "companyLogo", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#ae6fe83005fe37a48e6ce7e24309b9fd4", null ],
    [ "companyName", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#add47bd91b3418cf924df78545e6f436a", null ],
    [ "companyShortName", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#a5c4b6d269dede997e2af105ac7f3eb16", null ],
    [ "destination", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#a2e5cf1b961916a73e3ebc10f4283773a", null ],
    [ "flags", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#a3c88c651b9f9cd33115063b7682540b8", null ],
    [ "lineBackground", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#a5c0f55f759b88f97e94028a7fbc32f6f", null ],
    [ "lineForeground", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#a1fc98c8d66106e23c90cd93e3b149b2c", null ],
    [ "lineName", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#a5442209c75f1535e8decbb1cea013090", null ],
    [ "lineStyle", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#a8deb3f39af1b103d528f836703135aa8", null ],
    [ "stops", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#acf6374633669e897fa28b8467119e1e9", null ],
    [ "type", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#a6ff172c5b906ac86bce2ea68f559bb05", null ],
    [ "typeName", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine.html#a778b4bbea97aac75e85776de79c04199", null ]
];