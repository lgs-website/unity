var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1Stop =
[
    [ "id", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1Stop.html#aaad2214e19b062e30a1eee8570d3a10c", null ],
    [ "line", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1Stop.html#a26940ac6d8d9993ded31f096d3253bac", null ],
    [ "position", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1Stop.html#a6f266489b00f1df03e01d9bb7db9ddfe", null ],
    [ "stopName", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1Stop.html#a586d4eac450bae23c61ad357a68f0cc0", null ],
    [ "travelTime", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1PublicTransportLine_1_1Stop.html#a828169b1b8ea3004f916636f77f67c91", null ]
];