var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Incident =
[
    [ "criticality", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Incident.html#aed9ced886c8a14ccc9be85362f00f9d0", null ],
    [ "text", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Incident.html#a6469f11287c62ff5607c2f02d8c3fb01", null ],
    [ "type", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Incident.html#ab64c937ab196909acad1f2d5dddde59d", null ],
    [ "validityPeriod", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Incident.html#af32c710e5a803708c6ae62347610799b", null ]
];