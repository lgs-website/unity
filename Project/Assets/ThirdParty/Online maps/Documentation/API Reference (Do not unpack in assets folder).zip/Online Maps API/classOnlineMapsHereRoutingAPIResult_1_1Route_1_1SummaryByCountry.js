var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1SummaryByCountry =
[
    [ "country", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1SummaryByCountry.html#a1e7e65c81e6cc07ab008bfa52dc1e34a", null ],
    [ "tollRoadDistance", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1SummaryByCountry.html#a9a320fbe46d451aecb62cc82ba287272", null ]
];