var classOnlineMapsGooglePlacesAutocompleteResult =
[
    [ "MatchedSubstring", "classOnlineMapsGooglePlacesAutocompleteResult_1_1MatchedSubstring.html", "classOnlineMapsGooglePlacesAutocompleteResult_1_1MatchedSubstring" ],
    [ "Term", "classOnlineMapsGooglePlacesAutocompleteResult_1_1Term.html", "classOnlineMapsGooglePlacesAutocompleteResult_1_1Term" ],
    [ "OnlineMapsGooglePlacesAutocompleteResult", "classOnlineMapsGooglePlacesAutocompleteResult.html#a110b7e40ae9640ef833487fc7e7a12b8", null ],
    [ "description", "classOnlineMapsGooglePlacesAutocompleteResult.html#a56c34f60ce80a2dc3a807cd8468b2a12", null ],
    [ "id", "classOnlineMapsGooglePlacesAutocompleteResult.html#ac91de8c4c282d5e8d4537445f5fa3595", null ],
    [ "matchedSubstring", "classOnlineMapsGooglePlacesAutocompleteResult.html#a6a83bfb94c270d3bb8f5e3cc6c7ec2a5", null ],
    [ "place_id", "classOnlineMapsGooglePlacesAutocompleteResult.html#a0341fe41f44cc46358c4b06fc47add6b", null ],
    [ "reference", "classOnlineMapsGooglePlacesAutocompleteResult.html#aa210e91e939fac5244e78b777cdecb8f", null ],
    [ "terms", "classOnlineMapsGooglePlacesAutocompleteResult.html#a7327ea98b6932a897399ede6139704b5", null ],
    [ "types", "classOnlineMapsGooglePlacesAutocompleteResult.html#a860b30d1c7884f057acf0aa46de44df2", null ]
];