var classOnlineMapsTextWebService =
[
    [ "Destroy", "classOnlineMapsTextWebService.html#a0989c9b5a982b7ac5832da0e65b9feed", null ],
    [ "OnRequestComplete", "classOnlineMapsTextWebService.html#a7e06ef53a47c1ce636ecc11afeddfc36", null ],
    [ "OnComplete", "classOnlineMapsTextWebService.html#ac3d21eef3257ef94fcc64bdfacb04c62", null ],
    [ "response", "classOnlineMapsTextWebService.html#a9b81cd30b9b337f19762873c7728d0ff", null ]
];