var classOnlineMapsKeyboardInput =
[
    [ "speed", "classOnlineMapsKeyboardInput.html#a6348a32bb5871aa5a5adc9cc88f554c8", null ]
];