var classOnlineMapsOpenRouteServiceDirectionResult_1_1Segment =
[
    [ "ascent", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Segment.html#a0852b72b541b53b089a3db916ede66c4", null ],
    [ "descent", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Segment.html#a0f032db394cb1b809a0eee1457d87227", null ],
    [ "distance", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Segment.html#ade1b90946a4a11f47c7bc7ef5abc5b53", null ],
    [ "duration", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Segment.html#a21f85ac276b0ed6087f49afc20e07f52", null ],
    [ "steps", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Segment.html#ad9c1bd710771c04ab6727304f3782a23", null ]
];