var classOnlineMapsBuildingsNodeData =
[
    [ "OnlineMapsBuildingsNodeData", "classOnlineMapsBuildingsNodeData.html#a0de79fd652270b5cecb16cc1e49bef1e", null ],
    [ "Dispose", "classOnlineMapsBuildingsNodeData.html#a2fe60b2e2fc1782546c32f85082605ed", null ],
    [ "nodes", "classOnlineMapsBuildingsNodeData.html#ad0d289f85d45cd893dabda8f6b16fe71", null ],
    [ "way", "classOnlineMapsBuildingsNodeData.html#a8ce89fe777a3053282a7066803b49ef2", null ]
];