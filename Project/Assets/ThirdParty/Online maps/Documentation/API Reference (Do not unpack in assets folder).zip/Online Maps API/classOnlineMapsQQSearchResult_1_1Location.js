var classOnlineMapsQQSearchResult_1_1Location =
[
    [ "lat", "classOnlineMapsQQSearchResult_1_1Location.html#a4d61d9f75e9e89ad822a36e465cb6495", null ],
    [ "lng", "classOnlineMapsQQSearchResult_1_1Location.html#aa5068d312a9d6bdabbb43782eb02b26e", null ]
];