var classOnlineMapsOSMNominatim =
[
    [ "GetResults", "classOnlineMapsOSMNominatim.html#a4421da68192acbe9444e70a11caf7901", null ],
    [ "Reverse", "classOnlineMapsOSMNominatim.html#a3ed998440a46995da0e71cfd01fb81d9", null ],
    [ "Search", "classOnlineMapsOSMNominatim.html#a75fb534337f837019b858b667c3de960", null ]
];