var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1GeoCoordinate =
[
    [ "altitude", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1GeoCoordinate.html#ac29b49842083db6146a42c2d7c8fed50", null ],
    [ "latitude", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1GeoCoordinate.html#abd984ff2a5d2a2e3bf182f178347aceb", null ],
    [ "longitude", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1GeoCoordinate.html#af69faa7c7c8836299c4b2e3144a4d1d5", null ]
];