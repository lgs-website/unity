var classOnlineMapsTrafficProvider =
[
    [ "GetByID", "classOnlineMapsTrafficProvider.html#a6e819536360c914333436429d404237d", null ],
    [ "GetProviders", "classOnlineMapsTrafficProvider.html#a53dd4804031731adb8458ebf2203106c", null ],
    [ "GetURL", "classOnlineMapsTrafficProvider.html#aacd2b0d512acd5f23d7b5d23766b7260", null ],
    [ "id", "classOnlineMapsTrafficProvider.html#ae01c2f74b300300570a8011234d03311", null ],
    [ "isCustom", "classOnlineMapsTrafficProvider.html#a88b78fa7bb0b19606b8df88a4619386a", null ],
    [ "title", "classOnlineMapsTrafficProvider.html#af55d9d8b83d1e523b7fd7997979a6740", null ],
    [ "url", "classOnlineMapsTrafficProvider.html#a08da77c582a629064fb6df52129b7547", null ]
];