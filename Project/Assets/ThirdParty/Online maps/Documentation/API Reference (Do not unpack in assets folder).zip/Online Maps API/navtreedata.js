var NAVTREE =
[
  [ "Online Maps", "index.html", [
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", "functions_vars" ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Properties", "functions_prop.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"classOnlineMapsBuildingBase.html#a2420fdc36b6a9ff93f9a0983e7e3010f",
"classOnlineMapsDrawingPoly.html#a1023f9e616aee1c52b35b385dbd6d34c",
"classOnlineMapsGoogleDirectionsResult_1_1Route.html",
"classOnlineMapsGoogleRoads.html#abe4f30ff2e711bb0cf9bb8f56b0ac19d",
"classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Summary.html#ae1b1066248989c2a0ee26c7f47104c25",
"classOnlineMapsMarker3D.html#ab8bf2bce4052d57cc41bba741daafc0d",
"classOnlineMapsProvider_1_1ExtraField.html",
"classOnlineMapsUtils.html#a27629ff55a9c481e26c5c415764d95bc",
"structOnlineMapsBuildingBase_1_1MetaInfo.html#a7f533ebd6e740be83380531cb5b50ea8"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';