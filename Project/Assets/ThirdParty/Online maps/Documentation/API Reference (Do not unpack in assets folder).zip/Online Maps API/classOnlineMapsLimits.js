var classOnlineMapsLimits =
[
    [ "maxLatitude", "classOnlineMapsLimits.html#ae8464e6cc7d37632fea4b97d512c33a2", null ],
    [ "maxLongitude", "classOnlineMapsLimits.html#abb566bfaba27a026075256e45d8906a0", null ],
    [ "maxZoom", "classOnlineMapsLimits.html#a9f6c490f3fe23e10ab05db64dece1b5f", null ],
    [ "minLatitude", "classOnlineMapsLimits.html#a006a7f8e69c39e9496db1bc323b5123f", null ],
    [ "minLongitude", "classOnlineMapsLimits.html#a8f134ad0647d9eb105be4d0b49709c72", null ],
    [ "minZoom", "classOnlineMapsLimits.html#a1faf0f90f937b7afb34c1d3eaee6b437", null ],
    [ "positionRangeType", "classOnlineMapsLimits.html#a595db28526395aa2d0b9a2aa0ef58711", null ],
    [ "usePositionRange", "classOnlineMapsLimits.html#a6e6e978d108afedd3c32aa0b65df6f55", null ],
    [ "useZoomRange", "classOnlineMapsLimits.html#acc122bab20340648a40fbd616505973b", null ]
];