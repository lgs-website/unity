var classOnlineMapsProjectionSphericalMercator =
[
    [ "CoordinatesToTile", "classOnlineMapsProjectionSphericalMercator.html#adb372b9892277866045cc8ccc9c92fac", null ],
    [ "TileToCoordinates", "classOnlineMapsProjectionSphericalMercator.html#ad86a436caa5364954fb850dff49b73c8", null ]
];