var classOnlineMapsGoogleRoads_1_1SnapToRoadResult =
[
    [ "location", "classOnlineMapsGoogleRoads_1_1SnapToRoadResult.html#a6c4c72d97343898e606e32c9e29d20d0", null ],
    [ "originalIndex", "classOnlineMapsGoogleRoads_1_1SnapToRoadResult.html#ab843170bc08c4359957762e4c66e0f05", null ],
    [ "placeId", "classOnlineMapsGoogleRoads_1_1SnapToRoadResult.html#acd24e5ea8f9ebaa7cdae7d3871b69f4f", null ]
];