var classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Summary =
[
    [ "baseTime", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Summary.html#a16c65654826ce8e8f276c15bd9f6fd59", null ],
    [ "co2Emission", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Summary.html#a1991a6d357de5f2b3b74897401b309fd", null ],
    [ "costFactor", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Summary.html#a7f0aaded1b2568afcaebf795fa17654e", null ],
    [ "distance", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Summary.html#aa4ec422fcef7ff7872d6aa84051a713f", null ],
    [ "flags", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Summary.html#a3004efdd4fa2363fc2d3b91b9967ff0f", null ],
    [ "text", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Summary.html#ae1b1066248989c2a0ee26c7f47104c25", null ],
    [ "trafficTime", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Summary.html#a4001eae2bef1e5e2a4066b102e7a9652", null ],
    [ "travelTime", "classOnlineMapsHereRoutingAPIResult_1_1Route_1_1Summary.html#a654f59465a9efadb4ad369e1ebbbde0d", null ]
];