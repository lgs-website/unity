var classOnlineMapsGoogleRoads_1_1Location =
[
    [ "latitude", "classOnlineMapsGoogleRoads_1_1Location.html#a28f4d32e880f17274a6ca3900fb1d353", null ],
    [ "longitude", "classOnlineMapsGoogleRoads_1_1Location.html#ae90fc39e7f36be040e6e64d21af05b6f", null ]
];