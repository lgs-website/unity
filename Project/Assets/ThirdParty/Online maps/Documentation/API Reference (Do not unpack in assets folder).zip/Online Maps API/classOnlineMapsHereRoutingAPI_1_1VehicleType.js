var classOnlineMapsHereRoutingAPI_1_1VehicleType =
[
    [ "EngineType", "classOnlineMapsHereRoutingAPI_1_1VehicleType.html#accbe81bcfcb2e1fc2c129adc857274b7", [
      [ "diesel", "classOnlineMapsHereRoutingAPI_1_1VehicleType.html#accbe81bcfcb2e1fc2c129adc857274b7a02408123caf6bb364630361db9b81f7e", null ],
      [ "gasoline", "classOnlineMapsHereRoutingAPI_1_1VehicleType.html#accbe81bcfcb2e1fc2c129adc857274b7a80f5341801b20b8cde78b0f3aebeef8d", null ],
      [ "electric", "classOnlineMapsHereRoutingAPI_1_1VehicleType.html#accbe81bcfcb2e1fc2c129adc857274b7ab5a60207bdcc6a6621f1a81f00611d9d", null ]
    ] ],
    [ "averageConsumption", "classOnlineMapsHereRoutingAPI_1_1VehicleType.html#a140c5762be11ee4a7bfe71d1884ee9d0", null ],
    [ "engineType", "classOnlineMapsHereRoutingAPI_1_1VehicleType.html#a6b8f943ed521559ef09bd7587985bed0", null ]
];