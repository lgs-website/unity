var classOnlineMapsBuffer =
[
    [ "ApplyTile", "classOnlineMapsBuffer.html#a897762c99c67647711bbefa83fea5e33", null ],
    [ "Dispose", "classOnlineMapsBuffer.html#af34558244119e924c738e5712862ec1b", null ],
    [ "api", "classOnlineMapsBuffer.html#a864ddc37a464d6b855dc1e272390fa6d", null ],
    [ "apiZoom", "classOnlineMapsBuffer.html#a591859d58d1d678e99138b525adaaf88", null ],
    [ "bufferPosition", "classOnlineMapsBuffer.html#a5a72694c11a5a216514b060defddb415", null ],
    [ "height", "classOnlineMapsBuffer.html#a3999d869b6378128ca62b62ece400c48", null ],
    [ "OnSortMarker", "classOnlineMapsBuffer.html#a12f0a1826c1a4d79ecfff6ef1ceb2356", null ],
    [ "redrawType", "classOnlineMapsBuffer.html#a767b1af72a5f4fa47be988f6ea2f2ba4", null ],
    [ "status", "classOnlineMapsBuffer.html#abe886eccb01c0ee0f19dc1cda655b80f", null ],
    [ "width", "classOnlineMapsBuffer.html#a4d3913eca93a89e515d7b64f83aefb1d", null ],
    [ "apiPosition", "classOnlineMapsBuffer.html#a6bac9a211250e8ab6df343a7ca8c537c", null ],
    [ "topLeftPosition", "classOnlineMapsBuffer.html#a88b619caff0f5f4c37d4a30a6816357c", null ]
];