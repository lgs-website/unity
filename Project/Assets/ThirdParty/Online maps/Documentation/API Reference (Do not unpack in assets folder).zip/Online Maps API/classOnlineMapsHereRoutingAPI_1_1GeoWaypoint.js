var classOnlineMapsHereRoutingAPI_1_1GeoWaypoint =
[
    [ "GeoWaypoint", "classOnlineMapsHereRoutingAPI_1_1GeoWaypoint.html#a8085373cbcbca0358c636ffe14626cc9", null ],
    [ "altitude", "classOnlineMapsHereRoutingAPI_1_1GeoWaypoint.html#a7fb1316ceda8952e635c199f3ffc9890", null ],
    [ "latitude", "classOnlineMapsHereRoutingAPI_1_1GeoWaypoint.html#ae8facd254f622e08d2c858d9e78a4fa9", null ],
    [ "longitude", "classOnlineMapsHereRoutingAPI_1_1GeoWaypoint.html#a72342fcf77d6a22f18ceaa5e035852ee", null ],
    [ "transitRadius", "classOnlineMapsHereRoutingAPI_1_1GeoWaypoint.html#aca4a05b4c5af746153200d3d0e599669", null ],
    [ "userLabel", "classOnlineMapsHereRoutingAPI_1_1GeoWaypoint.html#a1e4cfa5abf5913dcc231f018ea6f8a73", null ]
];