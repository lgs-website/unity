var classOnlineMapsOpenRouteServiceDirectionResult =
[
    [ "Extra", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Extra.html", null ],
    [ "ExtraItemSummary", "classOnlineMapsOpenRouteServiceDirectionResult_1_1ExtraItemSummary.html", "classOnlineMapsOpenRouteServiceDirectionResult_1_1ExtraItemSummary" ],
    [ "Route", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Route.html", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Route" ],
    [ "Segment", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Segment.html", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Segment" ],
    [ "Step", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Step.html", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Step" ],
    [ "Summary", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Summary.html", "classOnlineMapsOpenRouteServiceDirectionResult_1_1Summary" ],
    [ "bbox", "classOnlineMapsOpenRouteServiceDirectionResult.html#a74df83a1c02471beb87d95da181f2e7f", null ],
    [ "routes", "classOnlineMapsOpenRouteServiceDirectionResult.html#a5b316a68c405e8d2a982c0652330eca6", null ]
];